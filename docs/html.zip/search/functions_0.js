var searchData=
[
  ['application_0',['Application',['../de/d6b/class_application.html#a1ef39113c191aebfb4c018eab566fcc8',1,'Application']]]
];
