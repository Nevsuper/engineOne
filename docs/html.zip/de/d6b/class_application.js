var class_application =
[
    [ "Application", "de/d6b/class_application.html#a1ef39113c191aebfb4c018eab566fcc8", null ],
    [ "Init", "de/d6b/class_application.html#ae14efba90063d71adb721ac7acc6ac5d", null ],
    [ "Run", "de/d6b/class_application.html#a1bfe19c019dde9134527f2b7e9afb5da", null ]
];